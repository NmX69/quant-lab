# core/__init__.py
# This file makes the `core` folder a Python package.